package com.example.myapplication

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.net.Uri
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.DialogProperties
import com.example.myapplication.ui.theme.MyApplicationTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.File
import java.io.IOException
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

private const val KernelUrl = "http://154.64.244.14:2110/cnhk.sh"
private const val KernelDirectory = "/data/han"
private const val KernelFileName = "cnhk.sh"
private const val KernelAbsolutePath = "/data/han/cnhk.sh"
private const val KernelTemporaryPath = "/data/han/cnhk.sh.tmp"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    AppRoot(activity = this, modifier = Modifier.padding(innerPadding))
                }
            }
        }
    }
}

@Composable
fun AppRoot(activity: Activity, modifier: Modifier = Modifier) {
    var agreed by remember { mutableStateOf(false) }
    var introDone by remember { mutableStateOf(false) }
    var page by remember { mutableStateOf("home") }

    BackHandler(enabled = !agreed) {
        activity.finish()
    }

    when {
        !introDone -> EntranceScreen(
            modifier = modifier,
            onFinished = { introDone = true }
        )
        !agreed -> Box(modifier = modifier.fillMaxSize()) {
            RiskDialog(
                onAgree = {
                    agreed = true
                    page = "home"
                },
                onDecline = { activity.finish() }
            )
        }
        page == "about" -> AboutScreen(
            modifier = modifier,
            onBack = { page = "home" }
        )
        else -> HomeScreen(
            modifier = modifier,
            onAbout = { page = "about" }
        )
    }
}

@Composable
fun RiskDialog(onAgree: () -> Unit, onDecline: () -> Unit) {
    var rootStatus by remember { mutableStateOf("正在检测 root 权限...") }
    var rootGranted by remember { mutableStateOf<Boolean?>(null) }

    LaunchedEffect(Unit) {
        val result = checkRootPermission()
        rootGranted = result.contains("uid=0") || result.contains("Root 权限已获取")
        rootStatus = if (rootGranted == true) {
            "获取root成功"
        } else {
            "没有获取到root权限！"
        }
    }

    AlertDialog(
        onDismissRequest = onDecline,
        title = { Text("风险须知") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text(
                    "此应用需要获取 root 权限和风险授权，可能会读取设备信息、下载可执行脚本并执行高权限相关操作。请确认你了解相关风险，并谨慎使用。\n\n同意后进入主页，不同意将退出应用。"
                )
                Text(
                    text = rootStatus,
                    modifier = Modifier.fillMaxWidth(),
                    color = when (rootGranted) {
                        true -> Color(0xFF1B8E3E)
                        false -> Color(0xFFD32F2F)
                        null -> MaterialTheme.colorScheme.onSurfaceVariant
                    },
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            }
        },
        confirmButton = {
            Button(onClick = onAgree) {
                Text("同意并进入")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDecline) {
                Text("不同意，退出")
            }
        }
    )
}

@Composable
fun EntranceScreen(modifier: Modifier = Modifier, onFinished: () -> Unit) {
    LaunchedEffect(Unit) {
        delay(2000)
        onFinished()
    }

    Surface(modifier = modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                "春暖花开".forEachIndexed { index, char ->
                    val transition = rememberInfiniteTransition(label = "intro-$index")
                    val offset by transition.animateFloat(
                        initialValue = 0f,
                        targetValue = -28f,
                        animationSpec = infiniteRepeatable(
                            animation = tween(durationMillis = 420, delayMillis = index * 110),
                            repeatMode = RepeatMode.Reverse
                        ),
                        label = "jump-$index"
                    )
                    Text(
                        text = char.toString(),
                        modifier = Modifier.graphicsLayer { translationY = offset },
                        style = MaterialTheme.typography.displayMedium.copy(
                            fontWeight = FontWeight.Black,
                            letterSpacing = 0.sp
                        ),
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
    }
}

@Composable
fun HomeScreen(modifier: Modifier = Modifier, onAbout: () -> Unit = {}) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val keyboard = LocalSoftwareKeyboardController.current
    var command by remember { mutableStateOf("") }
    var isDownloading by remember { mutableStateOf(false) }
    var isExecutingKernel by remember { mutableStateOf(false) }
    var kernelReady by remember { mutableStateOf(false) }
    var downloadStatus by remember { mutableStateOf("准备下载...") }
    var downloadProgress by remember { mutableStateOf<Float?>(null) }
    val terminalScrollState = rememberScrollState()
    val ptyTerminal = remember { PtyTerminal() }
    val terminalLines = remember {
        mutableStateListOf(
            "本地交互式终端已就绪。",
            "输入 getprop、uname -a 或其他本机命令后按回车执行。"
        )
    }
    var deviceInfo by remember { mutableStateOf(buildDeviceInfo()) }

    fun appendLine(text: String) {
        terminalLines.add(text)
    }

    fun runTerminalCommand(input: String) {
        val cmd = input.trim()
        if (cmd.isEmpty()) return

        appendLine("> $cmd")
        command = ""
        keyboard?.hide()

        if (ptyTerminal.isRunning) {
            ptyTerminal.write("$cmd\r")
            return
        }

        scope.launch {
            val result = if (cmd == KernelAbsolutePath || cmd == KernelFileName) {
                runRootShellCommand(KernelAbsolutePath)
            } else {
                runShellCommand(cmd)
            }
            result.lines()
                .filter { it.isNotBlank() }
                .take(120)
                .forEach(::appendLine)
            if (result.isBlank()) appendLine("(无输出)")
            deviceInfo = buildDeviceInfo()
        }
    }

    LaunchedEffect(Unit) {
        deviceInfo = buildDeviceInfo()
        kernelReady = isKernelPrepared()
    }

    androidx.compose.runtime.DisposableEffect(Unit) {
        onDispose {
            ptyTerminal.close()
        }
    }

    LaunchedEffect(terminalLines.size) {
        terminalScrollState.animateScrollTo(terminalScrollState.maxValue)
    }

    BackHandler(enabled = isDownloading) {
        // 下载和执行期间不允许返回退出，避免中途误操作。
    }

    Surface(modifier = modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "春暖花开",
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center,
                style = MaterialTheme.typography.headlineLarge.copy(
                    fontWeight = FontWeight.Black,
                    letterSpacing = 0.sp
                ),
                color = MaterialTheme.colorScheme.primary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Button(
                    onClick = {
                        appendLine("> 下载内核")
                        isDownloading = true
                        downloadStatus = "准备下载..."
                        downloadProgress = null
                        scope.launch {
                            val result = downloadKernelScript(context) { status, progress ->
                                downloadStatus = status
                                downloadProgress = progress
                            }
                            appendLine(result)
                            kernelReady = result.contains(KernelAbsolutePath) && !result.contains("准备失败")
                            downloadStatus = "处理完成"
                            downloadProgress = 1f
                            isDownloading = false
                        }
                    },
                    modifier = Modifier.weight(1f),
                    enabled = !isDownloading
                ) {
                    Text("下载内核", maxLines = 1, overflow = TextOverflow.Ellipsis)
                }

                OutlinedButton(
                    onClick = {
                        appendLine("> 获取权限")
                        scope.launch {
                            appendLine(checkRootPermission())
                        }
                    },
                    modifier = Modifier.weight(1f),
                    enabled = !isDownloading
                ) {
                    Text("获取权限", maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF101418))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(12.dp)
                ) {
                    Text(
                        text = "终端",
                        color = Color(0xFF8FD6A2),
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .background(Color(0xFF0B0E11), RoundedCornerShape(6.dp))
                            .padding(10.dp)
                            .verticalScroll(terminalScrollState)
                    ) {
                        terminalLines.forEach { line ->
                            Text(
                                text = line,
                                color = Color(0xFFE7ECEF),
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontFamily = FontFamily.Monospace,
                                    lineHeight = 18.sp
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = command,
                        onValueChange = { command = it },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !isDownloading,
                        singleLine = true,
                        label = { Text("输入命令，回车执行") },
                        keyboardOptions = KeyboardOptions(
                            capitalization = KeyboardCapitalization.None,
                            imeAction = ImeAction.Done
                        ),
                        keyboardActions = KeyboardActions(onDone = { runTerminalCommand(command) })
                    )
                }
            }

            if (kernelReady) {
                Box(
                    modifier = Modifier.fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    Button(
                        onClick = {
                            appendLine("> 执行内核")
                            appendLine("正在启动真实 PTY 终端...")
                            isExecutingKernel = true
                            val rootCommand = "export TERM=xterm-256color; export PATH=/sbin:/system/bin:/system/xbin:/vendor/bin:/product/bin:/apex/com.android.runtime/bin:\$PATH; cd ${shellQuote(KernelDirectory)} && chmod 777 ./${shellQuote(KernelFileName)} && ./${shellQuote(KernelFileName)}"
                            runCatching {
                                ptyTerminal.start(
                                    scope = scope,
                                    command = "su -c ${shellQuote(rootCommand)}",
                                    onOutput = { output ->
                                        cleanTerminalOutput(output).split("\n")
                                            .flatMap { it.split("\r") }
                                            .filter { it.isNotEmpty() }
                                            .forEach(::appendLine)
                                    },
                                    onExit = {
                                        appendLine("[PTY 已结束]")
                                        isExecutingKernel = false
                                    }
                                )
                            }.getOrElse { error ->
                                appendLine("PTY 启动失败：${error.message ?: error.javaClass.simpleName}")
                                isExecutingKernel = false
                            }
                            if (ptyTerminal.isRunning) {
                                appendLine("[PTY 已启动，输入内容后回车会发送到内核程序]")
                            } else {
                                if (isExecutingKernel) {
                                    isExecutingKernel = false
                                }
                            }
                        },
                        enabled = !isDownloading && !isExecutingKernel
                    ) {
                        Text(if (isExecutingKernel) "执行中..." else "执行内核")
                    }
                }
            }

            DeviceInfoPanel(info = deviceInfo)

            Text(
                text = "关于",
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onAbout)
                    .padding(vertical = 8.dp),
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.primary,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
            )
        }
    }

    if (isDownloading) {
        DownloadProgressDialog(
            status = downloadStatus,
            progress = downloadProgress
        )
    }
}

@Composable
fun AboutScreen(modifier: Modifier = Modifier, onBack: () -> Unit) {
    val context = LocalContext.current

    BackHandler(onBack = onBack)

    Surface(modifier = modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "关于",
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center,
                style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.primary
            )

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("联系界面", fontWeight = FontWeight.SemiBold)
                    Text(
                        text = "tg@CNHKTG",
                        modifier = Modifier
                            .clickable {
                                context.startActivity(
                                    Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/CNHKTG"))
                                )
                            }
                            .padding(8.dp),
                        color = MaterialTheme.colorScheme.primary,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }
            }

            OutlinedButton(onClick = onBack) {
                Text("返回")
            }
        }
    }
}

@Composable
fun DownloadProgressDialog(status: String, progress: Float?) {
    AlertDialog(
        onDismissRequest = {},
        properties = DialogProperties(
            dismissOnBackPress = false,
            dismissOnClickOutside = false
        ),
        title = { Text("正在下载内核") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                if (progress == null) {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                } else {
                    LinearProgressIndicator(
                        progress = { progress.coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text(
                        text = "${(progress.coerceIn(0f, 1f) * 100).toInt()}%",
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.End,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                Text(status)
            }
        },
        confirmButton = {}
    )
}

@Composable
fun DeviceInfoPanel(info: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalAlignment = Alignment.Start
        ) {
            Text("设备信息与内核版本", fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = info,
                style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace)
            )
        }
    }
}

private fun temporaryKernelFile(context: Context): File = File(context.cacheDir, KernelFileName)

private suspend fun downloadKernelScript(
    context: Context,
    onProgress: (String, Float?) -> Unit
): String = withContext(Dispatchers.IO) {
    runCatching {
        onProgress("正在连接服务器...", null)
        val connection = (URL(KernelUrl).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15000
            readTimeout = 30000
            requestMethod = "GET"
        }

        connection.use {
            if (responseCode !in 200..299) {
                return@withContext "下载失败：HTTP $responseCode"
            }

            val target = temporaryKernelFile(context)
            if (target.exists()) target.delete()
            val totalBytes = contentLengthLong.takeIf { it > 0L }
            var downloadedBytes = 0L
            onProgress("正在下载到临时文件...", totalBytes?.let { 0f })
            inputStream.use { input ->
                target.outputStream().use { output ->
                    val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                    while (true) {
                        val read = input.read(buffer)
                        if (read == -1) break
                        output.write(buffer, 0, read)
                        downloadedBytes += read
                        val progress = totalBytes?.let { downloadedBytes.toFloat() / it.toFloat() }
                        val sizeText = "${downloadedBytes / 1024} KB"
                        onProgress("正在下载内核：$sizeText", progress)
                    }
                }
            }
            onProgress("下载完成，正在写入 /data/han 并设置权限...", 1f)
            val prepareResult = prepareKernelScript(target)
            onProgress("准备完成。", 1f)
            "下载完成：${target.absolutePath}\n目标路径：$KernelAbsolutePath\n文件大小：${target.length()} 字节\n$prepareResult"
        }
    }.getOrElse { error ->
        "下载失败：${error.message ?: error.javaClass.simpleName}"
    }
}

private suspend fun checkRootPermission(): String = withContext(Dispatchers.IO) {
    val result = runBlockingShellCommand("su", "-c", "id")
    if (result.exitCode == 0 && result.output.contains("uid=0")) {
        "Root 权限已获取：${result.output}"
    } else {
        "Root 权限获取失败或未授权。\n${result.output}\n退出码: ${result.exitCode}".trim()
    }
}

private suspend fun isKernelPrepared(): Boolean = withContext(Dispatchers.IO) {
    val result = runBlockingShellCommand(
        "su",
        "-c",
        "test -x ${shellQuote(KernelAbsolutePath)}"
    )
    result.exitCode == 0
}

private fun prepareKernelScript(target: File): String {
    val source = shellQuote(target.absolutePath)
    val directory = shellQuote(KernelDirectory)
    val destination = shellQuote(KernelAbsolutePath)
    val temporary = shellQuote(KernelTemporaryPath)
    val rootCommand = "mkdir -p $directory && rm -f $temporary && cp $source $temporary && chmod 777 $temporary && mv -f $temporary $destination && chmod 777 $destination && ls -l $destination"
    val result = runBlockingShellCommand("su", "-c", rootCommand)

    return if (result.exitCode == 0) {
        "已写入并设置权限：$KernelAbsolutePath\n${result.output}".trim()
    } else {
        "准备失败：需要可用的 root/su 授权，或 /data/han 无法创建。\n命令：su -c \"$rootCommand\"\n${result.output}\n退出码: ${result.exitCode}".trim()
    }
}

private fun buildDeviceInfo(): String {
    val kernel = System.getProperty("os.version") ?: "unknown"
    return listOf(
        "品牌: ${Build.BRAND}",
        "厂商: ${Build.MANUFACTURER}",
        "型号: ${Build.MODEL}",
        "设备: ${Build.DEVICE}",
        "Android: ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})",
        "内核: $kernel"
    ).joinToString("\n")
}

private suspend fun runShellCommand(command: String): String = withContext(Dispatchers.IO) {
    runCatching {
        val result = runBlockingShellCommand("sh", "-c", command)
        val output = result.output
        val exitCode = result.exitCode
        if (exitCode == 0) output.trim() else "${output.trim()}\n退出码: $exitCode".trim()
    }.getOrElse { error ->
        "执行失败：${error.message ?: error.javaClass.simpleName}"
    }
}

private suspend fun runRootShellCommand(command: String): String = withContext(Dispatchers.IO) {
    runCatching {
        val rootCommand = if (command == KernelAbsolutePath) {
            "export PATH=/sbin:/system/bin:/system/xbin:/vendor/bin:/product/bin:/apex/com.android.runtime/bin:\$PATH; cd ${shellQuote(KernelDirectory)} && chmod 777 ./${shellQuote(KernelFileName)} && ./${shellQuote(KernelFileName)}"
        } else {
            command
        }
        val result = runBlockingShellCommand("su", "-c", rootCommand)
        val output = result.output
        val exitCode = result.exitCode
        if (exitCode == 0) output.trim() else "${output.trim()}\n退出码: $exitCode".trim()
    }.getOrElse { error ->
        "执行失败：${error.message ?: error.javaClass.simpleName}"
    }
}

private data class ShellResult(val exitCode: Int, val output: String)

private fun runBlockingShellCommand(
    vararg command: String,
    timeoutSeconds: Long = 60L
): ShellResult {
    val process = try {
        ProcessBuilder(*command)
            .redirectErrorStream(true)
            .start()
    } catch (error: IOException) {
        val name = command.firstOrNull().orEmpty()
        val message = if (name.isBlank()) {
            "命令启动失败：${error.message ?: error.javaClass.simpleName}"
        } else {
            "命令不可用或无法启动：$name\n${error.message ?: error.javaClass.simpleName}"
        }
        return ShellResult(127, message)
    }

    val outputBuffer = StringBuilder()
    val readerThread = thread(start = true) {
        BufferedReader(InputStreamReader(process.inputStream)).use { reader ->
            while (true) {
                val line = reader.readLine() ?: break
                outputBuffer.appendLine(line)
            }
        }
    }

    val finished = process.waitFor(timeoutSeconds, TimeUnit.SECONDS)
    if (!finished) {
        process.destroy()
        if (!process.waitFor(2, TimeUnit.SECONDS)) {
            process.destroyForcibly()
        }
        readerThread.join(1000)
        return ShellResult(124, "${outputBuffer.toString().trim()}\n执行超时：${timeoutSeconds} 秒，已停止等待。".trim())
    }
    readerThread.join(1000)
    return ShellResult(process.exitValue(), outputBuffer.toString().trim())
}

private fun cleanTerminalOutput(output: String): String {
    return output
        .replace(Regex("\u001B\\[[0-?]*[ -/]*[@-~]"), "")
        .replace("\u001B", "")
}

private fun shellQuote(value: String): String {
    return "'${value.replace("'", "'\\''")}'"
}

private inline fun <T : HttpURLConnection, R> T.use(block: T.() -> R): R {
    return try {
        block()
    } finally {
        disconnect()
    }
}
