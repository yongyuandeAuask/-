#include <jni.h>
#include <android/log.h>
#include <errno.h>
#include <fcntl.h>
#include <pty.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/wait.h>
#include <unistd.h>

#define LOG_TAG "PtyTerminal"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

extern "C" JNIEXPORT jintArray JNICALL
Java_com_example_myapplication_PtyTerminal_nativeStart(
        JNIEnv *env,
        jobject,
        jstring command,
        jint rows,
        jint cols) {
    const char *cmd = env->GetStringUTFChars(command, nullptr);
    if (cmd == nullptr) {
        return nullptr;
    }

    int master_fd = -1;
    struct winsize win{};
    win.ws_row = rows > 0 ? static_cast<unsigned short>(rows) : 24;
    win.ws_col = cols > 0 ? static_cast<unsigned short>(cols) : 80;

    pid_t pid = forkpty(&master_fd, nullptr, nullptr, &win);
    if (pid < 0) {
        LOGE("forkpty failed: %s", strerror(errno));
        env->ReleaseStringUTFChars(command, cmd);
        return nullptr;
    }

    if (pid == 0) {
        setenv("TERM", "xterm-256color", 1);
        setenv("PATH", "/sbin:/system/bin:/system/xbin:/vendor/bin:/product/bin:/apex/com.android.runtime/bin", 1);
        execl("/system/bin/sh", "sh", "-c", cmd, static_cast<char *>(nullptr));
        _exit(127);
    }

    env->ReleaseStringUTFChars(command, cmd);

    int flags = fcntl(master_fd, F_GETFD);
    if (flags >= 0) {
        fcntl(master_fd, F_SETFD, flags | FD_CLOEXEC);
    }

    jint result_values[2] = { master_fd, static_cast<jint>(pid) };
    jintArray result = env->NewIntArray(2);
    if (result == nullptr) {
        close(master_fd);
        kill(pid, SIGTERM);
        return nullptr;
    }
    env->SetIntArrayRegion(result, 0, 2, result_values);
    return result;
}

extern "C" JNIEXPORT jbyteArray JNICALL
Java_com_example_myapplication_PtyTerminal_nativeRead(
        JNIEnv *env,
        jobject,
        jint fd,
        jint maxBytes) {
    if (maxBytes <= 0) {
        maxBytes = 4096;
    }
    if (maxBytes > 65536) {
        maxBytes = 65536;
    }

    auto *buffer = static_cast<unsigned char *>(malloc(static_cast<size_t>(maxBytes)));
    if (buffer == nullptr) {
        return nullptr;
    }

    ssize_t count = read(fd, buffer, static_cast<size_t>(maxBytes));
    if (count <= 0) {
        free(buffer);
        return env->NewByteArray(0);
    }

    jbyteArray result = env->NewByteArray(static_cast<jsize>(count));
    if (result != nullptr) {
        env->SetByteArrayRegion(result, 0, static_cast<jsize>(count), reinterpret_cast<jbyte *>(buffer));
    }
    free(buffer);
    return result;
}

extern "C" JNIEXPORT jint JNICALL
Java_com_example_myapplication_PtyTerminal_nativeWrite(
        JNIEnv *env,
        jobject,
        jint fd,
        jbyteArray data) {
    if (data == nullptr) {
        return -1;
    }

    jsize length = env->GetArrayLength(data);
    if (length <= 0) {
        return 0;
    }

    jbyte *bytes = env->GetByteArrayElements(data, nullptr);
    if (bytes == nullptr) {
        return -1;
    }

    ssize_t written = write(fd, bytes, static_cast<size_t>(length));
    env->ReleaseByteArrayElements(data, bytes, JNI_ABORT);
    return static_cast<jint>(written);
}

extern "C" JNIEXPORT void JNICALL
Java_com_example_myapplication_PtyTerminal_nativeResize(
        JNIEnv *,
        jobject,
        jint fd,
        jint rows,
        jint cols) {
    struct winsize win{};
    win.ws_row = rows > 0 ? static_cast<unsigned short>(rows) : 24;
    win.ws_col = cols > 0 ? static_cast<unsigned short>(cols) : 80;
    ioctl(fd, TIOCSWINSZ, &win);
}

extern "C" JNIEXPORT void JNICALL
Java_com_example_myapplication_PtyTerminal_nativeClose(
        JNIEnv *,
        jobject,
        jint fd,
        jint pid) {
    if (fd >= 0) {
        close(fd);
    }
    if (pid > 0) {
        kill(pid, SIGTERM);
        for (int i = 0; i < 20; ++i) {
            int status = 0;
            pid_t waited = waitpid(pid, &status, WNOHANG);
            if (waited == pid) {
                return;
            }
            usleep(50000);
        }
        kill(pid, SIGKILL);
        waitpid(pid, nullptr, WNOHANG);
    }
}
